<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use MyPlot\MyPlot;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\PluginDescription;
use pocketmine\plugin\PluginLoader;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;

class RandSubCommand extends SubCommand
{

    protected $pl;
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */

    /**
     * @param CommandSender $sender
     *
     * @return bool
     */
    public function canUse(CommandSender $sender): bool
    {
        return ($sender instanceof Player) and $sender->hasPermission("myplot.command.rand");
    }
	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
		$plot = MyPlot::getInstance()->getPlotByPosition($sender);
		if($plot === null) {
			$sender->sendMessage(TextFormat::RED . $this->translateString("notinplot"));
			return true;
		}
        if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.rand")) {
            $sender->sendMessage(TextFormat::RED.$this->translateString("notowner"));
            return true;
        }

        if ($sender->hasPermission("plot.rand")) {

            $fdata = [];

            $fdata['title'] = '§cCityBuild';
            $fdata['buttons'] = [];
            $fdata['content'] = "§9Wahle Dein Rand";
            $fdata['type'] = 'form';

            $fdata['buttons'][] = ['text' => '§cVerlassen'];
            $fdata['buttons'][] = ['text' => '§bDia-Rand'];
            $fdata['buttons'][] = ['text' => '§bBeacon-Rand'];
            $fdata['buttons'][] = ['text' => '§6Gold-Rand'];
            $fdata['buttons'][] = ['text' => '§6Keinen Rand'];
            $fdata['buttons'][] = ['text' => '§bDrachen-ei-Rand'];
            $fdata['buttons'][] = ['text' => '§6Bücherregal-Rand'];
            $fdata['buttons'][] = ['text' => '§bSpawner-Rand'];
            $fdata['buttons'][] = ['text' => '§bEnderportalrahmen-Rand'];
            $fdata['buttons'][] = ['text' => '§6Seelaterne-Rand'];
            $fdata['buttons'][] = ['text' => '§6Glowstone-Rand'];
            $fdata['buttons'][] = ['text' => '§6TNT-Rand'];
            $fdata['buttons'][] = ['text' => '§7Bruchsteinstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Eichenholzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Fichtenholzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Birkenholzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Tropenholzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§bQuarzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Schwarzeichenholzstufe-Rand'];
            $fdata['buttons'][] = ['text' => '§7Ziegelstufen-Rand'];
            $fdata['buttons'][] = ['text' => '§6Kohleblock-Rand'];
            $fdata['buttons'][] = ['text' => '§6Eisen-Rand'];
            $fdata['buttons'][] = ['text' => '§bSmaragd-Rand'];
            $fdata['buttons'][] = ['text' => '§6Lapisblock-Rand'];
            $fdata['buttons'][] = ['text' => '§7GlatteSteinstufe-Rand'];


            $pk = new ModalFormRequestPacket();
            $pk->formId = 35335;
            $pk->formData = json_encode($fdata);

            $sender->sendDataPacket($pk);

            return true;
        }else{
            $sender->sendMessage("Du brauchst einen Premium oder Supreme um /p rand z");
        }
        return true;
	}
}
